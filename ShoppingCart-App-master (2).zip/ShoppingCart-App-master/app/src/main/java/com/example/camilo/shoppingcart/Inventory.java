package com.example.camilo.shoppingcart;

import android.content.Context;
import android.support.v4.util.Pair;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;
import java.io.Serializable;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by Camilo on 4/29/2016.
 */
public class Inventory extends ArrayList<Product> implements Serializable{

    public final static String SAMPLE_DESCRIPTION = ("â€¢\\tStyle: Sari\\n\" +\n" +
            "            \"â€¢\\tSaree Fabric: Net\\n\" +\n" +
            "            \"â€¢\\tBlouse Fabric: Silk\\n\" +\n" +
            "            \"â€¢\\tWith Blouse Piece\\n\" +\n" +
            "            \"â€¢\\tType: Bollywood\\n\" +\n" +
            "            \"â€¢\\t\\n\" +\n" +
            "            \"Specifications\\n\" +\n" +
            "            \"â€¢\\tStyle Code 32423423\\n\" +\n" +
            "            \"â€¢\\tPattern Embroidered\\n\" +\n" +
            "            \"â€¢\\tPack of 1\\n\" +\n" +
            "            \"â€¢\\tHand Embroidery No\\n\",s1");

    Inventory(){}

    public void saveMaster(File file){
        try {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void loadMaster(File file){
        try {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            this.clear();
            this.addAll((Inventory) ois.readObject());
            return;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (OptionalDataException e) {
            e.printStackTrace();
        } catch (StreamCorruptedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //no master inventory exists, populate with fake items
        final String username = "default";
        this.add(new Product(R.drawable.s1,
                "designer saree", 899, 80, 1, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s2,
                "silk saree", 999, 180, 2, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s3,
                "salwar suit", 499, 30, 3, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s4,
                "lehenga,choli", 799, 50, 4, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s5,
                "Salwar", 399, 20, 5, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s6,
                "cotton saree", 800, 10, 6, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s7,
                "lehenga,sleeveless", 1000, 80, 1, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s8,
                "patiyala suit", 760, 180, 2, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s9,
                "classic color,full sleeve", 599, 30, 3, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s10,
                "Castel1_black", 599, 50, 4, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s11,
                "mandarin,full seleeve", 499, 20, 5, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s12,
                "classic,half sleeve", 699, 10, 6, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s13,
                "casual,full,sleeve", 999, 30, 3, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s14,
                "casual,half sleeve", 799, 50, 4, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s15,
                "dupion", 599, 20, 5, SAMPLE_DESCRIPTION, username));
        this.add(new Product(R.drawable.s22,
                "dupion", 699, 10, 6, SAMPLE_DESCRIPTION, username));


    }


//master functions
    public Product getCloneByName(String name){
        for(Product p : this){
            if(p.getName().equals(name)) {
                return (Product)p.singleClone();
            }
        }
        return null;
    }
    public int getQtyByName(String name){
        for(Product p : this){
            if(name.equals(p.getName())) {
                return p.getQty();
            }
        }
        return 0;
    }
    public void deleteProduct(String name){
        for(Product p : this){
            if(name.equals(p.getName())) {
                remove(p);
                return;
            }
        }
    }
    public void checkout(ArrayList<Pair<String,Integer>> items){
        for(Pair pair : items){
            for(Product p : this){
                if(p.getName().equals(pair.first)) {
                    p.setQty(p.getQty() - (Integer)pair.second);
                }
            }
        }

    }
    public void updateQty(String name, int newQuantity){
        for(Product p : this){
            if(p.getName().equals(name)) {
                p.setQty(newQuantity);
            }
        }
    }
}